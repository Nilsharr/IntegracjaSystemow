﻿namespace IntegracjaSystemow.Models;

public enum RowStatus
{
    NotEdited,
    Edited,
    Duplicated,
}