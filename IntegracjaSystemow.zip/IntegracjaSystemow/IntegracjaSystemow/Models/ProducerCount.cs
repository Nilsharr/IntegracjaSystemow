﻿namespace IntegracjaSystemow.Models;

public class ProducerCount
{
    public string Producer { get; init; } = default!;
    public int Count { get; init; }
}