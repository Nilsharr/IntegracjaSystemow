﻿using ReactiveUI;

namespace IntegracjaSystemow.ViewModels;

public class ViewModelBase : ReactiveObject
{
}