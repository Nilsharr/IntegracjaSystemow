﻿using ReactiveUI;

namespace WebClient.ViewModels;

public class ViewModelBase : ReactiveObject
{
}